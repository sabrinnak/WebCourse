package p1;

public class Beef implements Type_of_Meat{


	@Override
	public double cost() {
		return 12.99;
	}

	@Override
	public String meatDescription() {
		return " beef ";
	}

}
