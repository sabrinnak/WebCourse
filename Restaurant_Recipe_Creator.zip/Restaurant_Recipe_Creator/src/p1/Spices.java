package p1;

public interface Spices {
	public abstract double cost();
	public abstract String spiceDescription();
}
