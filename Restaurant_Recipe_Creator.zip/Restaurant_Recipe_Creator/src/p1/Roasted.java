package p1;

public class Roasted implements Cooking_Behavior{


	@Override
	public String cookDescription() {
		return "roasted";
	}

}
