package p1;

public class WhitePepper implements Spices{


	@Override
	public double cost() {
		return .50;
	}

	@Override
	public String spiceDescription() {
		return "with white pepper.";
	}

}
