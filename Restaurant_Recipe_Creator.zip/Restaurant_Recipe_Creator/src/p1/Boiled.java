package p1;

public class Boiled implements Cooking_Behavior{

	@Override
	public String cookDescription() {
		return "boiled";
	}

}
