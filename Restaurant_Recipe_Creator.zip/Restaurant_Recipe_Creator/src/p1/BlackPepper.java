package p1;

public class BlackPepper implements Spices{

	@Override
	public double cost() {
		return .50;
	}

	@Override
	public String spiceDescription() {
		return "with black pepper.";
	}

}
