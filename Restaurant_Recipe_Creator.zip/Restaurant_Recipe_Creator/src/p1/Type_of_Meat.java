package p1;

public interface Type_of_Meat {
	public abstract double cost();
	public abstract String meatDescription();

}
