package p1;

public class Pork implements Type_of_Meat{


	@Override
	public double cost() {
		return 10.99;
	}

	@Override
	public String meatDescription() {
		return " pork ";
	}

}
