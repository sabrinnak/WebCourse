package p1;

public class Grilled implements Cooking_Behavior{

	@Override
	public String cookDescription() {
		return "grilled";
	}

	
}
