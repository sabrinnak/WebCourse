package p1;

public interface Cooking_Behavior {
	public abstract String cookDescription();
	
}
