package p1;

public class HouseSauce implements Spices{


	@Override
	public double cost() {
		return 1.25;
	}

	@Override
	public String spiceDescription() {
		return "with the house sauce.";
	}

}
