package p1;

public class Garlic implements Spices{

	@Override
	public double cost() {
		return .75;
	}

	@Override
	public String spiceDescription() {
		return "with garlic.";
	}

}
