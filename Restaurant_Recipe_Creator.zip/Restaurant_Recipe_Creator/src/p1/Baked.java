package p1;

public class Baked implements Cooking_Behavior{

	@Override
	public String cookDescription() {
		return "baked"; 
	}

}
