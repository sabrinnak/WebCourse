package p1;

public class Fish implements Type_of_Meat{

	
	@Override
	public double cost() {
		return 11.99;
	}

	@Override
	public String meatDescription() {
		return " fish ";
	}

	
}
