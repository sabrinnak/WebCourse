package p1;

import java.net.MalformedURLException;
import java.net.URL;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Recipe_GUI extends Application{
	Type_of_Meat meatchoice;
	Cooking_Behavior cookchoice;
	Spices spicechoice;
	TextArea maintxt = new TextArea();
	String description;
	String search;
	String cost;

	public void start(Stage stage) throws Exception {
		Pane root = recipePane();

		Scene scene = new Scene(root, 500, 400, Color.LIGHTBLUE);
		stage.setScene(scene);

		stage.setTitle("Create a recipe");
		stage.show();
	}
	
	public Pane recipePane() {
		GridPane gpane = new GridPane();
		gpane.setAlignment(Pos.CENTER);
		gpane.setHgap(10);
		gpane.setVgap(50);
		
		Label meatLabel = new Label("Select Desired Meat:");
		ComboBox<String> meat = new ComboBox<String>();
		meat.setPromptText("Meat");
		ObservableList<String> meatlist = meat.getItems();
		meatlist.add("Beef");
	    meatlist.add("Chicken");
	    meatlist.add("Fish");
	    meatlist.add("Pork");
	    
	    Label cookLabel = new Label("Select How to Cook:");
		ComboBox<String> cook = new ComboBox<String>();
		cook.setPromptText("How to Cook");
		ObservableList<String> cooklist = cook.getItems();
		cooklist.add("Baked");
	    cooklist.add("Boiled");
	    cooklist.add("Grilled");
	    cooklist.add("Roasted");
	    
	    Label spiceLabel = new Label("Select Desired Spice:");
		ComboBox<String> spice = new ComboBox<String>();
		spice.setPromptText("Spice");
		ObservableList<String> list = spice.getItems();
		list.add("Black Pepper");
	    list.add("Cinnamon");
	    list.add("Garlic");
	    list.add("House Sauce");
	    list.add("White Pepper");    
	   
	    gpane.add(meatLabel, 0, 0);
	    gpane.add(meat, 1, 0);
	    gpane.add(cookLabel, 0, 1);
	    gpane.add(cook, 1, 1);
	    gpane.add(spiceLabel, 0, 2);
		gpane.add(spice, 1, 2);
		
		HBox hbox = new HBox();
		hbox.setAlignment(Pos.CENTER_RIGHT);
		hbox.setSpacing(8);
		Button btnCreate = new Button("Create a Recipe");
		hbox.getChildren().addAll(btnCreate);
		
		gpane.add(btnCreate, 1, 3);
		
		
		btnCreate.setOnAction(e->{
			 Object selectedItem1 = meat.getSelectionModel().getSelectedItem();
			 Object selectedItem2 = cook.getSelectionModel().getSelectedItem();
			 Object selectedItem3 = spice.getSelectionModel().getSelectedItem();
			//meat
			if (selectedItem1 == "Beef") {
				meatchoice = new Beef();
			}
			if(selectedItem1 == "Chicken") {
				meatchoice = new Chicken();
			}
			if (selectedItem1 == "Fish") {
				meatchoice = new Fish();
			}
			if(selectedItem1 == "Pork") {
				meatchoice = new Pork();
			}
			
			//cook
			if(selectedItem2 == "Baked") {
				cookchoice = new Baked();
			}
			if(selectedItem2 == "Boiled") {
				cookchoice = new Boiled();
			}
			if(selectedItem2 == "Grilled") {
				cookchoice = new Grilled();
			}
			if(selectedItem2 == "Roasted") {
				cookchoice = new Roasted();
			}
			
			//spice
			if(selectedItem3 == "Black Pepper") {
				spicechoice = new BlackPepper();
			}
			if(selectedItem3 == "Cinnamon") {
				spicechoice = new Cinnamon();
			}
			if(selectedItem3 == "Garlic") {
				spicechoice = new Garlic();
			}
			if(selectedItem3 == "House Sauce") {
				spicechoice = new HouseSauce();
			}
			if(selectedItem3 == "White Pepper") {
				spicechoice = new WhitePepper();
			}
			
			description = "You have decided to make " + cookchoice.cookDescription() + meatchoice.meatDescription() + spicechoice.spiceDescription();
			search = "https://www.google.com/search?q=" + cookchoice.cookDescription() + "+" + meatchoice.meatDescription() +"+"+spicechoice.spiceDescription()+"&rlz=1C1CHBF_enUS881US881&oq=bak&aqs=chrome.0.69i59j69i57j35i39j46i67j69i60l4.1877j0j7&sourceid=chrome&ie=UTF-8";
			double newCost = meatchoice.cost() + spicechoice.cost();
			cost = "Potential cost: $" + newCost;
			
			maintxt.setText(description +"\nWhere to find recipes with these ingredients\n"+ search +"\n"+ cost);
			
			((Stage) (((Button) e.getSource()).getScene().getWindow())).close();
			Pane root2 = resultsPane();
			Scene scene2 = new Scene(root2, 500, 400, Color.BLUEVIOLET);
			Stage st = new Stage();
			st.setScene(scene2);
			st.setTitle("Recipe Created");
			st.show();
			
		});
		
		return gpane;
		
	}
	public Pane resultsPane() {
		BorderPane bp = new BorderPane();
		HBox hbox = new HBox();
		hbox.setAlignment(Pos.CENTER_RIGHT);
		hbox.setSpacing(8);
		Button btnSearch = new Button("Create Something Else");
		//Button btnNext = new Button("Next Page");
		hbox.getChildren().addAll(btnSearch);
		
		bp.setCenter(maintxt);

		bp.setBottom(hbox);
		
		/*btnNext.setOnAction(e ->{
			
		});*/
		
		btnSearch.setOnAction(e ->{
			((Stage) (((Button) e.getSource()).getScene().getWindow())).close();
			Pane root1 = recipePane();
			Scene scene1 = new Scene(root1, 500, 400, Color.BLUEVIOLET);
			Stage st = new Stage();
			st.setScene(scene1);
			st.setTitle("Create a Recipe");
			st.show();
		});
		
		return bp;
	}
 

	public static void main(String[] args) {
		Application.launch(args);

	}

}
